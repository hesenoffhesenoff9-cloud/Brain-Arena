# Brain Arena – Zunex Studios
Offline football quiz. Pure HTML/CSS/JS in `www/index.html`, no external files.

Test in browser: open `www/index.html`.

Build Android:
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android` -> Run, or Build > Build APK in Android Studio.

After editing `www/`, run `npx cap sync android` again.
Add questions in the `RAW` list: `category|difficulty|question|correct|wrong|wrong|wrong` (H/C/P/T, e/m/h).

## v1.1 additions
- **Daily missions** – 3 new missions each day (seeded by date, works offline), claim XP rewards + all-clear bonus.
- **Daily 10 challenge** – 10 fixed questions per day (3 easy, 4 medium, 3 hard). XP per correct answer + perfect bonus; replays are practice only.
- **Premium menu** – +50% XP, 50/50 lifeline, +5s per question, gold theme. Currently a local test unlock: set `BILLING_READY=true` and implement the purchase in `www/index.html` (`pmGo` handler / `setPremium`) with Google Play Billing before release.
- **Offline save** – progress stored in `localStorage` (`brainarena.v2` + backup copy `brainarena.bak`), auto-migrates v1 saves.


## BRAIN ARENA update
- Expanded offline question bank: 319 football questions.
- Added animated question/answer presentation and country flags / club monogram badges.
- Existing daily challenge, missions, XP, premium test mode, records and offline save are preserved.


## Question images (v1.2)

Question screens can fetch matching, openly licensed football club/player images from Wikimedia Commons. Images are downloaded on first view and cached on the device, so previously viewed images can display offline later. An internet connection is needed the first time each image is fetched. Image credits, license labels and source links are shown below the question image. If no suitable image is found or the device is offline, a built-in football icon placeholder is shown.


## New player modes (v1.3)
- Who is better? compares two players from the same position (goalkeeper, defender, midfielder or forward).
- Guess the country: identify a player's national team.
- Player's clubs: select a club the player has represented.
- Player photos are requested from Wikimedia Commons and cached on the device when available; first-time image loading requires internet. Photo author and licence are shown in the game.


## v1.5
- Zunex Studios logo splash screen on launch (tap to skip).
- Turkish / English language menu (top-left), all questions and answers translated.
- Country flags (SVG) on answer options; generated footballer avatars when photos are unavailable.
- New modes: Survival, Guess the player (clues), Two-player duel, Leaderboard.
- Question history: modes avoid repeating recently asked questions.
- Note: the Leaderboard shared board only works on the claude.ai artifact page; in the Android build it shows this device's best score only.


## v1.6
- **Player photos removed everywhere** (questions, "Who is better?", generated avatars). "Who is better?" now shows the player's flag, name and position. Question images are only shown for clubs/tournaments and only when an image actually loads, so no empty placeholder boxes remain.
- **4 new modes** (home screen, "Extra modes"):
  - Blitz: 60 seconds, as many questions as possible, a wrong answer costs 5 seconds.
  - True or false: 10 rounds, 10 s each, judge the proposed answer.
  - Flag quiz: guess the country from its flag (offline SVG flags).
  - Scrambled names: unscramble a footballer's name, with position and country as hints.
- Best scores are stored on the device. Turkish and English supported for all new texts.
- All modes are now in one "Modes" section.
- **Daily streak**: a 🔥 card on the home screen. Finishing any game, mode or mission claim each day raises the streak (resets after a missed day). Each new streak day gives bonus XP (20 per day, up to 140), with extra rewards at 3, 7, 14, 30, 60 and 100 days.
- **Rising difficulty**: every classic round goes from easy to hard (Easy 5/4/1, Medium 2/4/4, Hard 0/2/8 easy/medium/hard questions); time per question shrinks as the round goes on; Blitz moves to harder questions as you answer correctly; Survival and the round-based modes get less time over time; True/False goes easy to hard.
- **Who scored this goal?** (new mode): animated sketch-style replay (white pitch, black outlines) of 23 famous goals; the replay type matches the goal (solo run, free kick, bicycle kick, long shot, volley, header). Clues shrink with difficulty (easy: competition, year, opponent, type; medium: year, type; hard: type only), 4 easy, 3 medium, 3 hard per round. Tap the pitch to replay.

- **Home screen redesign**: glass cards, glowing title, colour-coded mode cards, segmented difficulty/topic chips, animated sticky Kick off button (styles are scoped to `#home`, other screens unchanged).


## v1.7
- **Who has more? / Kim Daha Fazla?** (new offline mode): two footballers are shown with flags; pick the one with the higher career stat. 10 rounds (3 easy, 4 medium, 3 hard – difficulty is the relative gap between the two values), time per round shrinks, faster answers score more. After each answer both values are revealed. Best score and daily streak are saved on the device; Turkish and English supported.
- Six stat categories, 160+ player entries: Ballon d'Or awards, Champions League / European Cup titles, World Cup goals, international goals, international caps, Premier League goals. Figures are as of end of 2025 (retired players' stats are final). Add or edit data in the `MS` object (and `PC` for the flag country) in `www/index.html`.

## v1.8
- **Career order / Kariyer Sıralaması** (new offline mode): a footballer is shown with his flag; tap his clubs in chronological order (oldest first). Tap a placed club to remove it, "Reset" clears all. 10 rounds: 3 with 3 clubs, 4 with 4 clubs, 3 with 5 clubs; time per round shrinks. Score: 20 per club in the right place, bonus for a perfect order + speed. Wrong answers show the correct order. Best score and daily streak saved on device; Turkish and English supported.
- 42 players in the `CR` list in `www/index.html` (clubs listed oldest → newest, main senior clubs only; short returns/loans are omitted). Add players there (and a flag country in `PC`).


## v1.9
- **Hidden player / Gizli Futbolcu** (new offline mode): a mystery footballer's clues unlock one by one (born year, position + nationality, clubs, two facts). The fewer clues you open, the more points the round is worth. 8 rounds, one guess per round. 49 players in the `HP` list in `www/index.html` (bilingual facts).
- **Shared "arena kit" for all 3 new modes** (Who has more?, Career order, Hidden player):
  - Difficulty picker (Easy / Medium / Hard) with per-difficulty best score; XP multiplier x1 / x1.5 / x2.
  - Points -> XP (1:1, +50% Premium), level-ups, daily streak and daily missions (games, correct answers, score, hard game) all count.
  - Records are saved on the device (`S.mb`) and listed under "New modes" in My records.
  - Premium glass/gold look: animated hero card, round timer ring, progress bar, star rating, result screen with XP bar. Scoped to `#mx .ak`, so older screens are unchanged.

## v2.0
- Modern home menu (aurora background, rounded glass cards, pill Start button).
- Start button no longer shrinks/clips; heavy blur and infinite shine effects removed to stop freezing on phones.
- +140 new football questions (409 total), fully translated to Turkish.

## v2.1
- Language menu now has Türkçe, Azərbaycanca, Русский, English.
- Azerbaijani: menus, buttons, modes, countries translated; questions and mode contents fall back to Turkish.
- Russian: menus, buttons, modes, countries and templated questions translated; other questions and mode contents fall back to English.

## v2.2
- New Tournament mode: pick one of 8 national teams, play quarter-final, semi-final and final (5 questions per match, penalty shootout question on a draw). Awards XP and keeps a best score.

## v2.3
- Russian: all 409 questions translated (Cyrillic UI, countries, derby/VAR answers); player and club names stay in Latin letters.
- Azerbaijani: templated questions and pair answers ("X və Y") translated; hand-written questions still fall back to Turkish.

## v2.4
- Question bank: 500 questions (91 new: Ballon d'Or winners by year, European Cup winners, Premier League champions, player nationalities, club countries, stadiums, founding and birth years, playing positions).
- All new questions are translated in TR, AZ and RU through patterns.

## v2.5
- Daily streak rewritten: play one game per day to grow the streak; a claimable daily reward (XP) appears on the streak card.
- 7-day reward calendar (tap the streak card), rewards grow every week, milestone bonuses at 3/7/14/30/60/100 days.
- Day 7 gives a Streak Shield (max 3) that saves the streak if one day is missed.

## v2.6
- Daily rewards now run on a calendar week (Monday to Sunday) and refresh every Monday.
- Each weekday has its own reward (Mon 30 ... Sun 250 XP, growing with streak weeks); claim once per day.
- Perfect week (all 7 days claimed): +300 XP and a Streak Shield. The overall day streak keeps counting across weeks.

## v2.7 — Username + global leaderboard
- First launch asks for a username (3-16 characters, unique, case/space-insensitive). It can be changed from the Leaderboard screen.
- Leaderboard tabs: Total points (XP), Survival, Guess the player. Points sync automatically.

### Turn on the real online ranking (Firebase Realtime Database, free tier)
1. console.firebase.google.com -> create a project -> Build -> Realtime Database -> Create database.
2. Paste these rules (Rules tab) and publish:
```
{
  "rules": {
    "lb": {
      ".read": true,
      ".indexOn": ["xp", "s", "h"],
      "$uid": { ".write": true, ".validate": "newData.hasChildren(['n','xp'])" }
    },
    "names": { "$n": { ".read": true, ".write": true } }
  }
}
```
3. Copy the database URL (looks like https://YOUR-APP-default-rtdb.firebaseio.com) and put it in `www/index.html`:
   `window.BA_FIREBASE_URL="https://YOUR-APP-default-rtdb.firebaseio.com";`
   (search for BA_FIREBASE_URL), then `npx cap sync android`.
- Without a URL the app stays fully offline and the board shows "this device only".
- Note: scores are sent by the app itself, so a determined user can fake a score. For a competitive release add server-side checks (Cloud Functions + App Check).
